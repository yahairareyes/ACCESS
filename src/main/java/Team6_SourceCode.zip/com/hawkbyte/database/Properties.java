/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hawkbyte.database;

/**
 *
 * @author Reknek
 */
public class Properties {
       
    private final String _USERNAME = "team6";
    private final  String _PASSWORD = "F1n@l pr0j3ct";
    //private final String _USERNAME = "root";
    //private final  String _PASSWORD = "";
    
    public String getUsername(){
        return _USERNAME;
    }
    
     public String getPassword(){
        return _PASSWORD;
    }
}
